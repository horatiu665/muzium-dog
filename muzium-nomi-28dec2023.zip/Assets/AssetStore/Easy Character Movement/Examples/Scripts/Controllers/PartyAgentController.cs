﻿using ECM.Controllers;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.AI;

public sealed class PartyAgentController : BaseAgentController
{
    public static List<PartyAgentController> allPartyAgents = new List<PartyAgentController>();

    [Tooltip("The character's walk speed.")]
    [SerializeField]
    private float _walkSpeed = 2.0f;

    [Tooltip("The character's run speed.")]
    [SerializeField]
    private float _runSpeed = 5.0f;

    public float drawDestinationDebugDuration = 0f;

    HashSet<Component> animationInhibitors = new HashSet<Component>();
    public void InhibitAnimation(Component sender)
    {
        animationInhibitors.Add(sender);
    }
    public void UninhibitAnimation(Component sender)
    {
        animationInhibitors.Remove(sender);
    }

    /// <summary>
    /// The character's walk speed.
    /// </summary>
    public float walkSpeed
    {
        get { return _walkSpeed; }
        set { _walkSpeed = value; }
    }

    /// <summary>
    /// The character's run speed.
    /// </summary>
    public float runSpeed
    {
        get { return _runSpeed; }
        set { _runSpeed = value; }
    }

    /// <summary>
    /// Walk input command.
    /// </summary>
    public bool walk;

    /// <summary>
    /// Get target speed based on character state (eg: running, walking, etc).
    /// </summary>
    private float GetTargetSpeed()
    {
        return walk ? walkSpeed : runSpeed;
    }

    /// <summary>
    /// Overrides 'BaseAgentController' CalcDesiredVelocity method to handle different speeds,
    /// eg: running, walking, etc.
    /// </summary>
    protected override Vector3 CalcDesiredVelocity()
    {
        // Modify base controller speed based on this character state

        speed = GetTargetSpeed();

        // Call the parent class' version of method

        return base.CalcDesiredVelocity();
    }


    /// <summary>
    /// Implements 'BaseAgentController' Animate method.
    /// 
    /// This shows how to handle your characters' animation states using the Animate method.
    /// The use of this method is optional, for example you can use a separate script to manage your
    /// animations completely separate of movement controller.
    /// </summary>
    /// 
    protected override void Animate()
    {
        // If no animator, return

        if (animator == null)
            return;

        if (animationInhibitors.Any())
        {
            // reset params here
            animator.SetFloat("Forward", 0, 0.1f, Time.deltaTime);
            animator.SetFloat("Turn", 0, 0.1f, Time.deltaTime);

            animator.SetBool("OnGround", movement.isGrounded);

            animator.SetBool("Crouch", isCrouching);

            return;
        }

        // Compute move vector in local space

        var move = transform.InverseTransformDirection(moveDirection);

        // Update the animator parameters

        var forwardAmount = animator.applyRootMotion
            ? Mathf.InverseLerp(0.0f, runSpeed, move.z * speed) * brakingRatio
            : Mathf.InverseLerp(0.0f, runSpeed, movement.forwardSpeed);

        animator.SetFloat("Forward", forwardAmount, 0.1f, Time.deltaTime);
        animator.SetFloat("Turn", Mathf.Atan2(move.x, move.z), 0.1f, Time.deltaTime);

        animator.SetBool("OnGround", movement.isGrounded);

        animator.SetBool("Crouch", isCrouching);

        if (!movement.isGrounded)
            animator.SetFloat("Jump", movement.velocity.y, 0.1f, Time.deltaTime);
    }

    public float animRotTowardsSmoothness = 0.1f;
    public float minDurationForAnimRotation = 0.5f;
    private float animRotationStartTime;
    bool animRotationActive;

    public void AnimateRotationTowards(Vector3 dir)
    {
        if (animationInhibitors.Any())
            return;

        if (!animRotationActive)
        {
            animRotationActive = true;
            animRotationStartTime = Time.time;
            StartCoroutine(pTween.WaitCondition(() =>
            {
                dir.y = 0;
                var move = transform.InverseTransformDirection(dir);
                animator.SetFloat("Turn", Mathf.Atan2(move.x, move.z), 0.1f, Time.deltaTime);
                // lerp transform as well?
                if (!animator.applyRootMotion)
                {
                    transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir, Vector3.up), animRotTowardsSmoothness);
                }

                return (move.x <= 0.1f) && (Time.time - animRotationStartTime > minDurationForAnimRotation);

            }, () =>
            {
                transform.rotation = Quaternion.LookRotation(dir, Vector3.up);
                animRotationActive = false;
            }));
        }

    }

    private void OnEnable()
    {
        allPartyAgents.Add(this);
    }
    private void OnDisable()
    {
        allPartyAgents.Remove(this);
        animRotationActive = false;
    }

    public override void FixedUpdate()
    {
        //base.FixedUpdate();

        // Pause / resume character
        //Pause();
        //// If paused, return
        //if (isPaused)
        //    return;

        if (animationInhibitors.Any())
        {
            // Move() but the parts that make it stand still
            this.movement.Move(Vector3.zero, 0f);
            return;
        }

        // Perform character movement
        Move();

        // Handle crouch
        Crouch();
    }


    public override void Update()
    {
        // base.Update();

        // Handle input
        //HandleInput();

        // If paused, return

        if (isPaused)
            return;

        if (animationInhibitors.Any())
            return;

        // Update character rotation (if not paused)

        UpdateRotation();

        // Perform character animation (if not paused)

        Animate();
    }

    public void GoTo(Vector3 destination)
    {
        if (animationInhibitors.Any())
            return;

        if (!agent.isOnNavMesh)
        {
            //set agent on navmesh...?
            if (NavMesh.SamplePosition(agent.transform.position, out var hit, 0.5f, agent.areaMask))
            {
                agent.Warp(hit.position);
            }
        }

        agent.isStopped = false;

        var succ = agent.SetDestination(destination);

        if (drawDestinationDebugDuration > 0)
        {
            Debug.DrawLine(transform.position, destination, Color.red, drawDestinationDebugDuration);
        }
    }

    public void StopMoving()
    {
        agent.isStopped = true;
    }


}

