﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

public class PartyAgentMoveToClick : MonoBehaviour
{
    [SerializeField]
    private Camera _mainCam;
    public Camera mainCam
    {
        get
        {
            if (_mainCam == null || !_mainCam.isActiveAndEnabled)
            {
                _mainCam = Camera.main;
            }
            if (_mainCam == null)
                _mainCam = FindObjectOfType<Camera>();
            return _mainCam;
        }
    }

    [SerializeField]
    private PartyAgentController _pac;
    public PartyAgentController pac
    {
        get
        {
            if (_pac == null)
            {
                _pac = GetComponent<PartyAgentController>();
            }
            return _pac;
        }
    }

    private void Update()
    {

        // If mouse right click,
        // found click position in the world
        if (Input.GetMouseButtonDown(1))
        {
            if (mainCam == null)
                return;

            var ray = mainCam.ScreenPointToRay(Input.mousePosition);

            RaycastHit hitInfo;
            if (Physics.Raycast(ray, out hitInfo, Mathf.Infinity, pac.groundMask.value))
            {
                pac.GoTo(hitInfo.point);
            }
        }
    }


}